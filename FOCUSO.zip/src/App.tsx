import { useEffect, useState } from 'react'
import { Nav } from './components/Nav'
import { Home } from './components/Home'
import { Checkout } from './components/Checkout'
import { Confirmation } from './components/Confirmation'
import { LanguageProvider } from './i18n'

type View = 'home' | 'checkout' | 'confirmation'

export default function App() {
  return (
    <LanguageProvider>
      <AppShell />
    </LanguageProvider>
  )
}

function AppShell() {
  const [view, setView] = useState<View>('home')
  const [qty, setQty] = useState(1)

  // Reset scroll on view change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'auto' })
  }, [view])

  const goOrder = () => setView('checkout')
  const goHome = () => setView('home')

  if (view === 'checkout') {
    return <Checkout qty={qty} setQty={setQty} onBack={goHome} onPlaced={() => setView('confirmation')} />
  }
  if (view === 'confirmation') {
    return <Confirmation onHome={goHome} />
  }

  return (
    <div className="min-h-screen">
      <Nav onOrder={goOrder} onHome={goHome} />
      <Home onOrder={goOrder} qty={qty} setQty={setQty} />
    </div>
  )
}
