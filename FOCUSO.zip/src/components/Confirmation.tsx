import { Button, IconCheck, Wordmark, LangToggle } from './primitives'
import { useLang } from '../i18n'

export function Confirmation({ onHome }: { onHome: () => void }) {
  const { t } = useLang()
  const c = t.confirmation
  const ref = 'FCS-' + Math.random().toString(36).slice(2, 7).toUpperCase()
  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-ink-15">
        <div className="mx-auto max-w-[1080px] px-6 md:px-10 h-[72px] flex items-center justify-between">
          <button onClick={onHome} className="hover:opacity-70"><Wordmark className="text-[24px]" /></button>
          <LangToggle />
        </div>
      </header>

      <main className="flex-1 grid place-items-center px-6 py-20">
        <div className="max-w-[34rem] text-center animate-fade">
          <span className="inline-grid place-items-center w-14 h-14 rounded-full bg-soft-green text-green">
            <IconCheck className="w-7 h-7" />
          </span>
          <h1 className="font-serif mt-8 text-[clamp(34px,5vw,48px)] leading-[1.1]">{c.title}</h1>
          <p className="mt-5 text-[17px] leading-[1.7] text-ink-60">
            {c.body}
          </p>

          <div className="mt-9 rounded-[14px] border border-ink-15 bg-white text-left divide-y divide-[rgba(50,50,50,0.14)]">
            {[
              [c.orderRef, ref],
              [c.delivery, c.deliveryVal],
              [c.payment, c.paymentVal],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between gap-4 px-5 py-4">
                <span className="text-[15px] text-ink-60">{k}</span>
                <span className={`text-[15px] text-right ${v.startsWith('[') ? 'font-mono text-ink-45' : 'font-medium text-ink'}`}>{v}</span>
              </div>
            ))}
          </div>

          <div className="mt-9">
            <Button onClick={onHome} variant="secondary">{c.back}</Button>
          </div>
        </div>
      </main>
    </div>
  )
}
