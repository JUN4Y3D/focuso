import { useState } from 'react'
import { Button, IconArrow, IconMinus, IconPlus, Wordmark, LangToggle } from './primitives'
import { DailyPage } from './PlannerPages'
import { useLang } from '../i18n'

function Field({
  label, id, type = 'text', placeholder, value, onChange, required, textarea,
}: {
  label: string; id: string; type?: string; placeholder?: string
  value: string; onChange: (v: string) => void; required?: boolean; textarea?: boolean
}) {
  const cls =
    'mt-2 w-full rounded-[10px] border border-ink-15 bg-white px-4 py-3 text-[16px] text-ink placeholder:text-ink-45 focus:border-green transition-colors'
  return (
    <label htmlFor={id} className="block">
      <span className="text-[14px] font-medium text-ink">
        {label}{required && <span className="text-green"> *</span>}
      </span>
      {textarea ? (
        <textarea id={id} rows={3} placeholder={placeholder} value={value}
          onChange={(e) => onChange(e.target.value)} className={cls + ' resize-none'} />
      ) : (
        <input id={id} type={type} placeholder={placeholder} value={value}
          onChange={(e) => onChange(e.target.value)} required={required} className={cls} />
      )}
    </label>
  )
}

export function Checkout({
  qty, setQty, onBack, onPlaced,
}: {
  qty: number; setQty: (n: number) => void; onBack: () => void; onPlaced: () => void
}) {
  const { t } = useLang()
  const c = t.checkout
  const [f, setF] = useState({ name: '', phone: '', address: '', city: '', notes: '' })
  const set = (k: keyof typeof f) => (v: string) => setF((p) => ({ ...p, [k]: v }))
  const [pay, setPay] = useState('cod')
  const valid = f.name && f.phone && f.address && f.city

  return (
    <div className="min-h-screen">
      <header className="border-b border-ink-15">
        <div className="mx-auto max-w-[1080px] px-6 md:px-10 h-[72px] flex items-center justify-between">
          <button onClick={onBack} className="hover:opacity-70"><Wordmark className="text-[24px]" /></button>
          <div className="flex items-center gap-6">
            <LangToggle />
            <button onClick={onBack} className="inline-flex items-center gap-2 text-[15px] text-ink-60 hover:text-ink">
              <IconArrow className="w-4 h-4 rotate-180" /> {c.back}
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1080px] px-6 md:px-10 py-12 md:py-16">
        <h1 className="font-serif text-[clamp(32px,5vw,44px)] leading-[1.1]">{c.title}</h1>
        <p className="mt-3 text-[16px] text-ink-60">{c.subtitle}</p>

        <form
          onSubmit={(e) => { e.preventDefault(); if (valid) onPlaced() }}
          className="mt-10 grid lg:grid-cols-[1.3fr_1fr] gap-10 lg:gap-16 items-start"
        >
          {/* Delivery */}
          <div className="space-y-8">
            <section>
              <h2 className="text-[13px] font-semibold tracking-[0.16em] uppercase text-green">{c.deliveryDetails}</h2>
              <div className="mt-5 grid gap-5">
                <Field label={c.fields.name.label} id="name" placeholder={c.fields.name.ph} value={f.name} onChange={set('name')} required />
                <div className="grid sm:grid-cols-2 gap-5">
                  <Field label={c.fields.phone.label} id="phone" type="tel" placeholder={c.fields.phone.ph} value={f.phone} onChange={set('phone')} required />
                  <Field label={c.fields.city.label} id="city" placeholder={c.fields.city.ph} value={f.city} onChange={set('city')} required />
                </div>
                <Field label={c.fields.address.label} id="address" placeholder={c.fields.address.ph} value={f.address} onChange={set('address')} required />
                <Field label={c.fields.notes.label} id="notes" placeholder={c.fields.notes.ph} value={f.notes} onChange={set('notes')} textarea />
              </div>
            </section>

            <section>
              <h2 className="text-[13px] font-semibold tracking-[0.16em] uppercase text-green">{c.paymentMethod}</h2>
              <div className="mt-5 grid gap-3">
                {[['cod', c.cod], ['other', c.otherPay]].map(([v, l]) => (
                  <label key={v} className={`flex items-center gap-3 rounded-[10px] border px-4 py-4 cursor-pointer transition-colors ${pay === v ? 'border-green bg-soft-green' : 'border-ink-15'}`}>
                    <input type="radio" name="pay" checked={pay === v} onChange={() => setPay(v)} className="sr-only" />
                    <span className={`grid place-items-center w-5 h-5 rounded-full border-2 ${pay === v ? 'border-green' : 'border-ink-15'}`}>
                      {pay === v && <span className="w-2.5 h-2.5 rounded-full bg-green" />}
                    </span>
                    <span className={`text-[16px] ${l.startsWith('[') ? 'font-mono text-ink-45' : 'text-ink'}`}>{l}</span>
                  </label>
                ))}
              </div>
            </section>
          </div>

          {/* Order summary */}
          <aside className="rounded-[16px] border border-ink-15 bg-white p-6 lg:sticky lg:top-24">
            <h2 className="text-[13px] font-semibold tracking-[0.16em] uppercase text-green">{c.orderSummary}</h2>
            <div className="mt-5 flex gap-4">
              <div className="w-20 h-24 rounded-[8px] overflow-hidden bg-soft-green border border-ink-15 shrink-0 grid place-items-center p-1.5">
                <DailyPage className="w-full h-auto" />
              </div>
              <div className="min-w-0">
                <p className="text-[16px] font-semibold leading-tight">{c.productName}</p>
                <p className="text-[14px] text-ink-60 mt-1">{c.productMeta}</p>
                <div className="mt-3 inline-flex items-center border border-ink-15 rounded-[8px]">
                  <button type="button" onClick={() => setQty(Math.max(1, qty - 1))} disabled={qty <= 1}
                    className="px-2.5 py-1.5 text-ink hover:text-green disabled:opacity-30" aria-label="Decrease quantity"><IconMinus /></button>
                  <span className="w-8 text-center text-[15px] font-semibold tabular-nums">{qty}</span>
                  <button type="button" onClick={() => setQty(Math.min(9, qty + 1))}
                    className="px-2.5 py-1.5 text-ink hover:text-green" aria-label="Increase quantity"><IconPlus /></button>
                </div>
              </div>
            </div>

            <dl className="mt-6 space-y-3 text-[15px] border-t border-ink-15 pt-5">
              {[[c.subtotal, c.subtotalVal], [c.delivery, c.deliveryVal]].map(([k, v]) => (
                <div key={k} className="flex justify-between">
                  <dt className="text-ink-60">{k}</dt>
                  <dd className="font-mono text-ink-45">{v}</dd>
                </div>
              ))}
              <div className="flex justify-between border-t border-ink-15 pt-3">
                <dt className="text-[16px] font-semibold">{c.total}</dt>
                <dd className="font-mono text-ink-45">{c.totalVal}</dd>
              </div>
            </dl>

            <Button full className="mt-6" type="submit" disabled={!valid}>{c.placeOrder}</Button>
            <p className="mt-4 text-[13px] text-ink-45 text-center">{c.safeNote}</p>
          </aside>
        </form>
      </main>
    </div>
  )
}
